# بناء نسخة Release

من جهاز عليه Flutter وAndroid Studio:

flutter pub get
flutter build appbundle --release

سيظهر الملف عادةً داخل:
build/app/outputs/bundle/release/app-release.aab

قبل أول رفع:
- أنشئ upload keystore خاصاً بك.
- خزّن بياناته خارج Git.
- اربط Play App Signing في Play Console.
- لا ترسل لي كلمة مرور keystore.

مهم:
هذا المشروع مجهز كمصدر Publish-ready، لكن لا يمكن إنشاء توقيع Google Play أو رفع التطبيق إلى حسابك نيابةً عنك من دون الوصول إلى حساب Play Console ومفاتيح التوقيع.
