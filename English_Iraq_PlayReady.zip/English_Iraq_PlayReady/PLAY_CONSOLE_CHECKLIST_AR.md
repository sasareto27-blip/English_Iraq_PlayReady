# Checklist قبل النشر على Google Play

1. إنشاء تطبيق جديد في Play Console باسم English Iraq.
2. استخدام package name: com.englishiraq.app
3. رفع Android App Bundle بصيغة .aab وليس APK.
4. ضبط توقيع Release حقيقي؛ لا تستخدم debug signing في النسخة المنشورة.
5. إنشاء صفحة Privacy Policy عامة على رابط HTTPS ووضع الرابط في Play Console.
6. إكمال Data Safety وفق البيانات الفعلية بعد ربط Firebase/Analytics/Payments.
7. إضافة أي حساب تجريبي تحتاجه Google لمراجعة الميزات المقفلة.
8. رفع أيقونة التطبيق ولقطات الشاشة.
9. إضافة وصف التطبيق والتصنيف.
10. إجراء اختبار داخلي ثم Closed testing ثم الإنتاج وفق متطلبات الحساب.
11. التأكد من استهداف Android 16 / API 36 للتطبيق الجديد؛ Google Play يطلب ذلك للتطبيقات الجديدة اعتباراً من 31 أغسطس 2026.
12. لا تضع كلمات مرور أو مفاتيح API أو ملف keystore داخل Git أو داخل ملف ZIP المرسل.
