# Privacy Policy — English Iraq

Last updated: September 11, 2026

English Iraq ("the App") is an English-learning application.

## Information
The current prototype does not require an account and does not intentionally collect personal information from within the app.

If future versions add accounts, cloud synchronization, analytics, speech services, or payments, this policy must be updated before those features are enabled and before publication.

## Third-party services
The current prototype does not intentionally transmit user data to third-party services.

## Children
The app is designed for general English learning. Parents or guardians should supervise use by minors.

## Security
We take reasonable measures to protect information when online services are introduced.

## Contact
Before publishing, replace this placeholder with the app owner's real support email:
support@example.com

## Changes
This privacy policy may be updated when the app's data practices change.
