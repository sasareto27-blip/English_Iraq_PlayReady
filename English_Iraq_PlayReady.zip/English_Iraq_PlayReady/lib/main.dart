import 'package:flutter/material.dart';

void main() => runApp(const EnglishIraqApp());

class EnglishIraqApp extends StatelessWidget {
  const EnglishIraqApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'English Iraq',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: const Color(0xFFF7F9FC),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087EA4)),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;

  final pages = const [
    DashboardPage(),
    LessonsPage(),
    SpeakingPage(),
    ProgressPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'الدروس'),
          NavigationDestination(icon: Icon(Icons.mic_none), selectedIcon: Icon(Icons.mic), label: 'محادثة'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'التقدم'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('أهلاً بك 👋', style: TextStyle(fontSize: 16, color: Colors.black54)),
                  SizedBox(height: 4),
                  Text('لنُكمل الإنجليزية اليوم', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            CircleAvatar(
              radius: 25,
              backgroundColor: Color(0xFFE2F3F8),
              child: Icon(Icons.person, color: Color(0xFF087EA4)),
            )
          ],
        ),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF087EA4),
            borderRadius: BorderRadius.circular(24),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مستواك الحالي', style: TextStyle(color: Colors.white70, fontSize: 15)),
              SizedBox(height: 5),
              Text('B1 • Intermediate', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
              SizedBox(height: 15),
              LinearProgressIndicator(value: .58, minHeight: 8, backgroundColor: Colors.white24, color: Colors.white),
              SizedBox(height: 10),
              Text('58% من المستوى مكتمل', style: TextStyle(color: Colors.white)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Row(
          children: const [
            Expanded(child: StatCard(title: 'سلسلة التعلم', value: '7 🔥')),
            SizedBox(width: 12),
            Expanded(child: StatCard(title: 'كلمات جديدة', value: '320')),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle('تابع تعلمك'),
        const SizedBox(height: 10),
        LessonCard(title: 'Daily English', subtitle: 'مفردات ومحادثة يومية', icon: Icons.today, progress: .72),
        LessonCard(title: 'English for Work', subtitle: 'المقابلات والبريد الإلكتروني', icon: Icons.work_outline, progress: .35),
        LessonCard(title: 'Grammar Boost', subtitle: 'قواعد مهمة لمستوى B1', icon: Icons.auto_stories, progress: .48),
        const SizedBox(height: 18),
        const SectionTitle('تدريب سريع'),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LevelTestPage())),
          icon: const Icon(Icons.assessment_outlined),
          label: const Text('اختبار تحديد المستوى A1 → C1'),
        ),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final String title, value;
  const StatCard({super.key, required this.title, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: Colors.black54)),
      const SizedBox(height: 7),
      Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    ]),
  );
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold));
}

class LessonCard extends StatelessWidget {
  final String title, subtitle;
  final IconData icon;
  final double progress;
  const LessonCard({super.key, required this.title, required this.subtitle, required this.icon, required this.progress});
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    margin: const EdgeInsets.only(bottom: 10),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: Padding(
      padding: const EdgeInsets.all(15),
      child: Row(children: [
        CircleAvatar(backgroundColor: const Color(0xFFE2F3F8), child: Icon(icon, color: const Color(0xFF087EA4))),
        const SizedBox(width: 13),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Text(subtitle, style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: progress, minHeight: 5),
        ])),
        const Icon(Icons.chevron_right),
      ]),
    ),
  );
}

class LessonsPage extends StatelessWidget {
  const LessonsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('الدروس', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('من الصفر إلى C1 بخطة واضحة', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 20),
      ...['A1 Beginner', 'A2 Elementary', 'B1 Intermediate', 'B2 Upper-Intermediate', 'C1 Advanced']
          .map((x) => Card(
            elevation: 0,
            child: ListTile(
              leading: const Icon(Icons.play_circle_fill, color: Color(0xFF087EA4)),
              title: Text(x, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Grammar • Vocabulary • Listening • Speaking'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuizPage(level: x))),
            ),
          )),
      const SizedBox(height: 18),
      Card(
        color: const Color(0xFFFFF4DA),
        child: const ListTile(
          leading: Icon(Icons.work, color: Color(0xFFB57A00)),
          title: Text('English for Work', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('CV • Interviews • Emails • Workplace conversations'),
        ),
      )
    ],
  );
}

class SpeakingPage extends StatelessWidget {
  const SpeakingPage({super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('ممارسة المحادثة', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('تحدث بالإنجليزية بثقة، خطوة بخطوة.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 25),
      Container(
        height: 260,
        width: double.infinity,
        decoration: BoxDecoration(
          color: const Color(0xFFEAF5F8),
          borderRadius: BorderRadius.circular(24),
        ),
        child: const Center(child: Icon(Icons.record_voice_over, size: 90, color: Color(0xFF087EA4))),
      ),
      const SizedBox(height: 18),
      const Text('Tell me about your job.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const Text('تحدث عن عملك لمدة 30 ثانية.', style: TextStyle(color: Colors.black54)),
      const Spacer(),
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          onPressed: () {},
          icon: const Icon(Icons.mic),
          label: const Text('ابدأ التسجيل'),
        ),
      )
    ]),
  );
}

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('التقدم', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 18),
      Card(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('سلسلة التعلم', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 5),
            const Text('7 أيام 🔥', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children:
              ['سبت','أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة'].map((d) => Column(children: [
                CircleAvatar(radius: 16, backgroundColor: const Color(0xFFE2F3F8), child: const Icon(Icons.check, size: 16, color: Color(0xFF087EA4))),
                const SizedBox(height: 4), Text(d, style: const TextStyle(fontSize: 10))
              ])).toList()),
          ]),
        ),
      ),
      const SizedBox(height: 14),
      Row(children: const [
        Expanded(child: StatCard(title: 'الدروس المكتملة', value: '48')),
        SizedBox(width: 10),
        Expanded(child: StatCard(title: 'الاختبارات', value: '12')),
      ]),
      const SizedBox(height: 10),
      Row(children: const [
        Expanded(child: StatCard(title: 'الكلمات الجديدة', value: '320')),
        SizedBox(width: 10),
        Expanded(child: StatCard(title: 'المستوى', value: 'B1')),
      ]),
      const SizedBox(height: 20),
      const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('كل يوم خطوة أقرب إلى مستقبلك المشرق 🇮🇶', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)))),
    ],
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('الملف الشخصي', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      const CircleAvatar(radius: 48, backgroundColor: Color(0xFFE2F3F8), child: Icon(Icons.person, size: 55, color: Color(0xFF087EA4))),
      const SizedBox(height: 10),
      const Center(child: Text('متعلم English Iraq', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      const Center(child: Text('متعلم English Iraq', style: TextStyle(color: Colors.black54))),
      const SizedBox(height: 24),
      ...['مستواي', 'كلماتي المحفوظة', 'إنجازاتي', 'الإعدادات', 'الدعم'].map((x) => Card(
        elevation: 0,
        child: ListTile(title: Text(x), trailing: const Icon(Icons.chevron_right)),
      )),
      const SizedBox(height: 14),
      Card(
        color: const Color(0xFF087EA4),
        child: ListTile(
          textColor: Colors.white,
          iconColor: Colors.white,
          leading: const Icon(Icons.workspace_premium),
          title: const Text('English Iraq Premium', style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: const Text('25,000 د.ع / شهر', style: TextStyle(color: Colors.white70)),
          trailing: const Icon(Icons.arrow_forward),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PremiumPage())),
        ),
      ),
    ],
  );
}

class LevelTestPage extends StatelessWidget {
  const LevelTestPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('اختبار تحديد المستوى')),
    body: Padding(
      padding: const EdgeInsets.all(22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('A1 → C1', style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: Color(0xFF087EA4))),
        const SizedBox(height: 12),
        const Text('اكتشف مستواك في دقائق واحصل على خطة تعلم مناسبة لك.', style: TextStyle(fontSize: 18)),
        const Spacer(),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizPage(level: 'Level Test'))), child: const Text('ابدأ الاختبار'))),
      ]),
    ),
  );
}

class QuizPage extends StatefulWidget {
  final String level;
  const QuizPage({super.key, required this.level});
  @override
  State<QuizPage> createState() => _QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  String? selected;
  final options = ['to', 'for', 'at', 'on'];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.level)),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('السؤال 1 / 10', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 25),
        const Text('Choose the correct answer:', style: TextStyle(fontSize: 17)),
        const SizedBox(height: 8),
        const Text('I would like ______ a coffee.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        ...options.map((o) => RadioListTile<String>(value: o, groupValue: selected, onChanged: (v) => setState(() => selected = v), title: Text(o))),
        const Spacer(),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: selected == null ? null : () {}, child: const Text('السؤال التالي'))),
      ]),
    ),
  );
}

class PremiumPage extends StatelessWidget {
  const PremiumPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Premium')),
    body: Padding(
      padding: const EdgeInsets.all(22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.workspace_premium, size: 70, color: Color(0xFF087EA4)),
        const SizedBox(height: 15),
        const Text('English Iraq Premium', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('25,000 د.ع شهرياً', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 22),
        ...['جميع الدروس من A1 إلى C1', 'تدريب Speaking متقدم', 'English for Work', 'اختبارات وتقييم التقدم', 'بدون إعلانات'].map((x) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 7),
          child: Row(children: [const Icon(Icons.check_circle, color: Color(0xFF087EA4)), const SizedBox(width: 10), Text(x, style: const TextStyle(fontSize: 17))]),
        )),
        const Spacer(),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: () {}, child: const Text('اشترك الآن'))),
        const SizedBox(height: 8),
        const Center(child: Text('الدفع الإلكتروني سيتم ربطه في المرحلة التالية.', style: TextStyle(color: Colors.black45))),
      ]),
    ),
  );
}
